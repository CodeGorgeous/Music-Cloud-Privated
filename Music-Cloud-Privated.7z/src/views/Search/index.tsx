import { TextField } from '@mui/material';

interface IProps {}
const HomeComponent: React.FC<IProps> = (props) => {
    return (
        <div className="home-container">
            
        </div>
    )
}

export default HomeComponent;