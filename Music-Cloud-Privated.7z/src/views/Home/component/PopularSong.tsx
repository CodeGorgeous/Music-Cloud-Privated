interface IProps {}

const PopularSong: React.FC<IProps> = (props) => {
    return (
        <div>
            用户喜欢的歌手对应的热门歌曲
        </div>
    )
}

export default PopularSong;