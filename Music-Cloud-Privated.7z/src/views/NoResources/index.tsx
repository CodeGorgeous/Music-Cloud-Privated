interface IProps {}

const Component: React.FC<IProps> = (props) => {
    return (
        <>暂时没有资源</>
    )
}

export default Component;