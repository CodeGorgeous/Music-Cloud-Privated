interface IProps {}

const Component: React.FC<IProps> = (props) => {
    return (
        <>Care页面</>
    )
}

export default Component;