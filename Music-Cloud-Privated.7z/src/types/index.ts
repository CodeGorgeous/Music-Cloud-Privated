export interface IMenu {
    key: number
    icon: any
    label: string
    route: string
}