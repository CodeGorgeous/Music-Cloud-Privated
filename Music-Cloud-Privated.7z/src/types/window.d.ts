declare global {
    interface Window {
        env: {
            uid: string
        }
    }
}